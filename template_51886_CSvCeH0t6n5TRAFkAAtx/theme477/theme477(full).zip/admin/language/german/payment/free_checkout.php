<?php
// Heading
$_['heading_title']      = 'ohne Bezahlung';

// Text
$_['text_payment']       = 'Zahlung';
$_['text_success']       = 'Erfolgreich: Modul Ohne Bezahlung wurde geändert!';

// Entry
$_['entry_order_status'] = 'Auftragsstatus:';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Reihenfolge:';

// Error
$_['error_permission']   = 'Warnung: Sie haben keine Berechtigung, um Ohne Bezahlung zu ändern!';
?>