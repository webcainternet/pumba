<?php
// Heading
$_['heading_title']       = 'Amazon Zahlungen';

$_['text_module']         = 'Module';
$_['text_success']        = 'Erfolgreich: Amazon Zahlungen wurden geändert!';
$_['text_content_top']    = 'Inhalt oben';
$_['text_content_bottom'] = 'Inhalt unten';
$_['text_column_left']    = 'Spalte links';
$_['text_column_right']   = 'Spalte rechts';

$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Position:';
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Reihenfolge:';

$_['error_permission']    = 'Warnung: Sie haben keine Berechtigung, um das Modul Amazon Zahlungen zu ändern!';
?>