<?php
// Heading
$_['heading_title']  = 'Gesehene Produkte';

// Text
$_['text_success']   = 'Erfolgreich: Report wurde zurückgesetzt!';

// Column
$_['column_name']    = 'Bezeichnung';
$_['column_model']   = 'Modell';
$_['column_viewed']  = 'Angesehen';
$_['column_percent'] = 'Prozent';
?>