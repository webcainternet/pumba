<?php
// Heading 
$_['heading_title']    = 'Erweiterungsmanager';

// Text
$_['text_success']     = 'Erfolgreich: Die Erweiterung wurde installiert!';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um den Erweiterungsmanager zu ändern!';
$_['error_upload']     = 'Warnung: Upload benötigt!';
$_['error_filetype']   = 'Warnung: Ungültiger Dateityp!';
?>