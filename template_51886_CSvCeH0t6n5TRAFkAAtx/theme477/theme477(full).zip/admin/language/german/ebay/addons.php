<?php
$_['lang_openbay']          = 'OpenBay Pro';
$_['lang_page_title']       = 'OpenBay Pro für eBay';
$_['lang_ebay']             = 'eBay';
$_['lang_heading']          = 'Module';
$_['lang_addon_desc']       = 'Module erweitern die Funktionalität von OpenBay Pro';
$_['lang_addon_name']       = 'Bezeichnung';
$_['lang_addon_version']    = 'Version';
$_['lang_addon_none']       = 'Es sind keine Module installiert.';
$_['lang_error_validation'] = 'Sie müssen sich registrieren, um den API Token zu bekommen und können dann das Modul aktivieren.';
$_['lang_btn_return']       = 'Zurück';
?>