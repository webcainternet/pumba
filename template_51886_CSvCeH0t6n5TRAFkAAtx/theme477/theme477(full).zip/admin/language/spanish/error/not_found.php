<?php
// Heading
$_['heading_title'] = 'Página No Encontrada!';

// Text
$_['text_not_found'] = 'La Página que andas buscando no pudo ser encontrada. Por favor contacte al administrador si el problema persiste.';
?>
