<?php
// Heading
$_['heading_title'] = 'Permiso denegado!';

// Text
$_['text_permission'] = 'No tienes los permisos para acceder a esta página, por favor contacta a tu administrador del sistema.';
?>
