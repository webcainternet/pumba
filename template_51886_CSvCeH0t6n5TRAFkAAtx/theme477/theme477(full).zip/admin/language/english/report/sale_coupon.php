<?php
// Heading
$_['heading_title']    = 'Coupon Report';

// Column
$_['column_name']      = 'Coupon Name';
$_['column_code']      = 'Code';
$_['column_orders']    = 'Orders';
$_['column_total']     = 'Total';
$_['column_action']    = 'Action';

// Entry
$_['entry_date_start'] = 'Date Start:';
$_['entry_date_end']   = 'Date End:';
?>